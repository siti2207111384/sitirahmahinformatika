﻿using System;

namespace TebakKata
{
    internal class Program
    {
        static int kesempatan = 5;
        static string KataMisteri = "Boss Baby";
        static List<string> ListTebakan = new List<string>{};


        static void Main(string[] args)
        {
            Intro();
            MulaiMain();
        }

        static void Intro(){
            //Mulai Permainan
            Console.WriteLine("Hai! Sekarang kita akan bermain game Tebak Kata");
            Console.WriteLine($"Kamu mempunyai {kesempatan} kesempatan untuk menebak kata misteri ini");
            Console.WriteLine("Clue nya adalah, kata ini merupakan nama film animasi 3D");
            Console.WriteLine($"Kata tersebut terdiri dari {KataMisteri.Length} huruf");
            Console.WriteLine("Film apakah yang di maksud?");
            Console.ReadKey();
            Console.WriteLine();
        }

        static void MulaiMain(){
            while(kesempatan > 0){
                Console.Write("Huruf apa yang ingin kamu tebak? (pilih a-z dan spasi)");
                Console.WriteLine();
                string input = Console.ReadLine();
                ListTebakan.Add(input);

                if(CekJawaban(KataMisteri, ListTebakan)){
                    //Jika tebakan benar
                    Console.WriteLine("Selamat, anda berhasil menebak katanya!");
                    Console.WriteLine($"Kata misterinya adalah {KataMisteri}");
                    break;
                }else if(KataMisteri.Contains(input)){
                    Console.WriteLine("Yey! Huruf tersbut ada di dalam kata ini!");
                    Console.WriteLine("Silakan tebak huruf lainnya!");
                    
                    //menampilkan huruf yang sudah tertebak
                    Console.WriteLine(Cekhuruf(KataMisteri, ListTebakan));
                }else{
                    Console.WriteLine("Huruf itu tidak ada dalam kata ini!");
                    kesempatan--; //kesempatan = kesempatan - 1;
                    Console.WriteLine($"Kesempatanmu tinggal {kesempatan}");
                }

                if(kesempatan == 0){
                    Endgame();
                    break;
                }
            }

            static bool CekJawaban(string KataMisteri, List<string> list){
                bool status = false;

                for (int i = 0; i < KataMisteri.Length; i++)
                {
                    string c = Convert.ToString(KataMisteri[i]);
                    if(list.Contains(c)){
                        status = true;
                    }else{
                        return status = false;
                    }
                }

                return status;
            }

            static string Cekhuruf(string KataMisteri, List<string> list){
                string x = "";

                for (int i = 0; i < KataMisteri.Length; i++)
                {
                    string c = Convert.ToString(KataMisteri[i]);
                    if(list.Contains(c)){
                        x = x + c;
                    }else{
                        x = x + ".";
                    }
                }

                return x;
            }

            static void Endgame(){
                //Game Over
                Console.WriteLine("Kamu tidak bisa menebak judul Film animasi itu!");
                Console.WriteLine($"Kata Misteri sebenarnya adalah {KataMisteri}");
                Console.WriteLine("Terima kasih sudah bermain, sampai jumba lagi!");
            }
        }
    }
}
