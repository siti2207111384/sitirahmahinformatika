﻿using System;

namespace Daspro_Kelas
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome To My Adventure Game!");
            Console.WriteLine("What Is Your Name?");
            BoboiboyApi Player = new BoboiboyApi();
            Player.Name = Console.ReadLine();
            Console.WriteLine("Hello " + Player.Name + ", are you ready to begin this game?[yes/no]");
            string bReady = Console.ReadLine();
            
            if(bReady == "yes"){
                Console.WriteLine(Player.Name + " is entering the World...");
                Enemy enemy1 = new Enemy("Adudu");
                Enemy2 enemy2 = new Enemy2("Borara");

                Console.WriteLine(Player.Name + " is encountering " + enemy1.Name);
                Console.WriteLine(enemy1.Name + " attacking you!");
                Console.WriteLine("Choose your action : ");
                Console.WriteLine("1. Single Attack");
                Console.WriteLine("2. Swing Attack");
                Console.WriteLine("3. Defend");
                Console.WriteLine("4. Run Away");

                while (!Player.IsDead && !enemy1.IsDead)
                {
                    string playerAction = Console.ReadLine();
                    switch(playerAction){
                        case "1" :
                        Console.WriteLine(Player.Name + " is doing the Single Attack!");
                        enemy1.GetHit(Player.AttackPower);
                        Player.Experience += 2.0f;
                        enemy1.Attack(enemy1.AttackPower);
                        Player.GetHit(enemy1.AttackPower); 
                        Console.WriteLine("Player Health " + Player.Health + " | Enemy Health " + enemy1.Health + "\n");
                        break;

                        case "2" :
                        Player.FireBall();
                        Player.Experience += 5.0f;
                        enemy1.GetHit(Player.AttackPower);
                        break;

                        case "3" :
                        Player.TakeARest();
                        Console.WriteLine("Energy is being restored...");
                        enemy1.Attack(enemy1.AttackPower);
                        Player.GetHit(enemy1.AttackPower);
                        Console.WriteLine("Player Health " + Player.Health + " | Enemy Health " + enemy1.Health + "\n");
                        break;

                        case "4" :
                        Console.WriteLine(Player.Name + " is running away..."); 
                        break;
                    }
                }

               Console.WriteLine(Player.Name + " get " + Player.Experience + " experience point.");

               while(!Player.IsDead && enemy1.IsDead && !enemy2.IsDead)
               {
                string playerAction = Console.ReadLine();
                    switch(playerAction){
                        case "1" :
                        Console.WriteLine(Player.Name + " is doing the Single Attack!");
                        enemy2.GetHit(Player.AttackPower);
                        Player.Experience += 2.0f;
                        enemy2.Attack(enemy2.AttackPower);
                        Player.GetHit(enemy2.AttackPower); 
                        Console.WriteLine("Player Health " + Player.Health + " | Enemy Health " + enemy2.Health + "\n");
                        break;

                        case "2" :
                        Player.FireBall();
                        Player.Experience += 5.0f;
                        enemy2.GetHit(Player.AttackPower);
                        break;

                        case "3" :
                        Player.TakeARest();
                        Console.WriteLine("Energy is being restored...");
                        enemy2.Attack(enemy2.AttackPower);
                        Player.GetHit(enemy2.AttackPower);
                        Console.WriteLine("Player Health " + Player.Health + " | Enemy Health " + enemy2.Health + "\n");
                        break;

                        case "4" :
                        Console.WriteLine(Player.Name + " is running away..."); 
                        break;
                    }
                }

               Console.WriteLine(Player.Name + " get " + Player.Experience + " experience point.");

               }else{
                Console.WriteLine("OK!");
                Console.Read();
            }
        }
    }

    class BoboiboyApi
    {
        public int Health { get; set; }
        public string Name { get; set; }
        public int AttackPower { get; set; }
        public int SkillSlot { get; set; }
        public bool IsDead { get; set; }
        public float Experience { get; set; }
        Random rnd = new Random();

        public BoboiboyApi()
        {
            Health = 2000;
            SkillSlot = 0;
            AttackPower = 10;
            IsDead = false;
            Experience = 0f;
            Name = "Newbie";
        }

        public void FireBall()
        {
            if(SkillSlot > 0){
                Console.WriteLine("BURN!!");
                AttackPower = AttackPower + rnd.Next(20,81);
                SkillSlot--;
            }else{
                Console.WriteLine("You haven't an energy!");
            }
        }

        public void GetHit(int hitValue)
        {
            Console.WriteLine(Name + " get hit by " + hitValue);
            Health = Health - hitValue;

            if(Health <= 0){
                Health = 0;
                Die();
            }
        }

        public void TakeARest()
        {
            SkillSlot = 3;
            AttackPower = 10;
        }

        public void Die()
        {
            Console.WriteLine("You are Dead, GAME OVER!");
            IsDead = true;
        }

    }

    class Enemy
    {
        public string Name { get; set; }
        public int Health { get; set; }
        public int AttackPower { get; set; }
        public bool IsDead { get; set; }
        Random rnd = new Random();

        public Enemy(string enemy1)
        {
            Health = 800;
            Name = enemy1;  
        }

        public void Attack(int damage)
        {
            AttackPower = rnd.Next(10,101);
        }

        public void GetHit(int hitValue)
        {
            Console.WriteLine(Name + " get hit by " + hitValue);
            Health = Health - hitValue;
            Console.WriteLine();

            if(Health <= 0){
                Health = 0;
                Die();
            }
        }

        public void Die()
        {
            Console.WriteLine(Name + " is Dead!");
            IsDead = true;

        }
    }

    class Enemy2
    {
        public string Name { get; set; }
        public int Health { get; set; }
        public int AttackPower { get; set; }
        public bool IsDead { get; set; }
        Random rnd = new Random();

        public Enemy2(string enemy2)
        {
            Health = 1500;
            Name = enemy2;  
        }

        public void Attack(int damage)
        {
            AttackPower = rnd.Next(10,101);
        }

        public void GetHit(int hitValue)
        {
            Console.WriteLine(Name + " get hit by " + hitValue);
            Health = Health - hitValue;
            Console.WriteLine();

            if(Health <= 0){
                Health = 0;
                Die();
            }
        }

        public void Die()
        {
            Console.WriteLine(Name + " is Dead!");
            IsDead = true;
            Console.WriteLine("CONGRATULATION YOU WIN!!!");
            Console.WriteLine();
        }
    }
}
