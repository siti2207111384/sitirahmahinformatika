<template>
    <v-footer id="footer" dark height="auto">
        <v-card class="flex" flat tile>
            <v-card-title id="card" class="green darken-4">
                <strong class="subheading"> Hubungi Sosial Media Kami </strong>
                <v-spacer></v-spacer>
                <v-btn v-for="icon in icons"
                :key="icon" class="mx-3" dark icon>
                    <v-icon size="25px"> {{ icon }}</v-icon>
                </v-btn>
            </v-card-title>
            <v-card-actions id="copyright" class="grey darken-4 justify-center">
                ©2022 - <strong> Universitas Riau </strong>
            </v-card-actions>
        </v-card>
    </v-footer>
</template>

<script>

export default {
    data: () => ({
        icons: [
            'mdi-facebook',
            'mdi-twitter',
            'mdi-google-plus',
            'mdi-instagram',
            'mdi-linkedin'
        ]
    })
}
</script>

<style>
#footer {
    position: absolute;
    bottom: 0;
    width: 100%;
    background-color: darkgreen;
}
#card {
    background-color: darkgreen;
}
#copyright {
    justify-content: center;
}
</style>
