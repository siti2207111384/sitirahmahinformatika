<template>
  <div id="app">
    <img src="./assets/logounri.png" height="75" width="75">
    <h1> UNIVERSITAS RIAU </h1>
    <web-toolbar></web-toolbar>
    <web-home>
      <web-login></web-login>
    </web-home>
      <router-view/>
    <web-footer></web-footer>
  </div>
  
</template>

<script>
import WebFooter from './components/WebFooter.vue'
import WebToolbar from './components/WebToolbar.vue'
import WebLogin from './components/WebLogin.vue'
import WebHome from './components/WebHome.vue'

export default {
  name: 'App',
  components: {WebFooter,WebToolbar,WebLogin,WebHome}
}
</script>

<style lang="scss">
#app {
  font-family: 'Aviner', Arial, Helvetica, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: left;
  color: #2c3e50;
}
</style>
