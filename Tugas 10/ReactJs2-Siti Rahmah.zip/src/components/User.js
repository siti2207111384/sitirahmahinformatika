import Info from "./Info";
import React, {Component} from "react";

class User extends Component{
    render () {
        return(
            <div>
                <h1> Ini Halaman User </h1>
                <Info />
            </div>
        )
    }
}

export default User;