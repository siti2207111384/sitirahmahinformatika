import Info from "./Info";
import React, {Component} from "react";

class Blog extends Component{
    render () {
        return(
            <div>
                <h1> Ini Halaman Blog </h1>
                <Info />
            </div>
        )
    }
}

export default Blog;