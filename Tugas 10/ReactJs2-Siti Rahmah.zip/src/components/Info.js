import React, {Component} from "react";

class Info extends Component{
    render () {
        return(
            <div>
                <h1> Info Page </h1>
                <p> Pemrograman Framework : React </p>
                <Info />
            </div>
        )
    }
}

export default Info;