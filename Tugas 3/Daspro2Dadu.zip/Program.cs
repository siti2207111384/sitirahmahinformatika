﻿//Name  : Siti Rahmah (1)
//Prodi : Teknik Informatika
//NIM   : 2207111384

 using System;


namespace MainDaduVsKomputer
{
    class Program
    {
        //Main Method
        static void Main(string[] args)
        {
            Console.Title = "Main_Game_Dadu";
            Console.ForegroundColor = ConsoleColor.Green;
            Intro();
            PlayGame();
            Outro();

        }

        static void Intro()
        {
            //Intro
            Console.WriteLine("GAME DADU\n");
            Console.WriteLine("---------------------------------------------------");
            Console.WriteLine("Welcome Dice Game Player!");
            Console.WriteLine("Di sini kamu akan berduel dengan Komputer sebanyak 10 Ronde");
            Console.WriteLine("Kamu dan Komputer akan melempar dadu setiap Ronde");
            Console.WriteLine("Yang memperoleh poin terbanyak ialah pemenangnya!");
            Console.WriteLine("---------------------------------------------------\n");
        }

        static void PlayGame(){
            //Deklarasi Variabel
            int ComputerDice;
            int YourDice;

            int jumlahRonde = 0;
            int ComputerPoint = 0;
            int YourPoint = 0;

            //Buat Random Number Generator (RNG)
            Random rng = new Random();

            for (int i = 0; i < 10; i++)
            {
                //Intro
                Console.WriteLine("\nKlik spasi untuk mengulirkan dadu.\n");

                Console.ReadKey();

                jumlahRonde++;
                Console.WriteLine("Ronde " +jumlahRonde);
                ComputerDice = rng.Next(1, 7);
                Console.WriteLine("Komputer mengggulirkan dadu dan mendapatkan angka " + ComputerDice + ".");
                Console.ReadKey();
                Console.Write("...");
                System.Threading.Thread.Sleep(1000);
                Console.Write("\b\b\b\b");
                YourDice = rng.Next(1, 7);
                Console.WriteLine("Anda sedang menggulirkan dadu dan mendapatkan angka " + YourDice + ".");

                if (YourDice > ComputerDice)
                {
                    YourPoint++;
                    Console.WriteLine("Kamu memenangkan ronde ini!");
                }else if (ComputerDice > YourDice){
                    ComputerPoint++;
                    Console.WriteLine("Komputer memenangkan ronde ini!");
                }else {
                    Console.WriteLine("Yah! Ronde ini seri");
                }

                Console.WriteLine("Skormu saat ini: " + YourPoint + " || Skor komputer saat ini: " + ComputerPoint);
                Console.WriteLine("-------------------------------------------------------------------------------");

            }

            if (YourPoint > ComputerPoint)
            {
                Console.WriteLine("\n-----------------------------------------------------------------------------");
                Console.WriteLine("YOU WIN!!");
                Console.WriteLine("-----------------------------------------------------------------------------"); 
            }else if (ComputerPoint > YourPoint) {
                Console.WriteLine("\n-----------------------------------------------------------------------------");
                Console.WriteLine("COMPUTER WIN!!");
                Console.WriteLine("-----------------------------------------------------------------------------");
            }else {
                Console.WriteLine("\n-----------------------------------------------------------------------------");
                Console.WriteLine("Permainan ini seri!!");
                Console.WriteLine("-----------------------------------------------------------------------------");
            }
            Console.ReadKey();

        }
        static void Outro()
        {
            Console.WriteLine("\nTHANK YOU!");
            Console.WriteLine("Permainan ini dibuat oleh.");
            Console.WriteLine("Name     : Siti Rahmah (No. Urut Absen 01)");
            Console.WriteLine("Prodi    : Teknik Informatika - A");
            Console.WriteLine("NIM      : 2207111384");
            Console.ReadKey();
        }

        }
    }
    
