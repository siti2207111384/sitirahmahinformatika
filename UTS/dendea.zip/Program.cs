﻿using System;

namespace DendaPerpustakaan
{
    class Program
    {
        static void Main(string[] args)
        {
            Permulaan();
        
        }

        static void Permulaan()
        {
            int JumlahDenda = 0;
            int DendaLimaHari = 50000;
            int DendaSetelahLimaHari = 400000;

            Console.Write("Input jumlah hari peminjaman : ");
            int Hari = Convert.ToInt32(Console.ReadLine());

            if(Hari <= 0 && Hari <= 5)
            {
                JumlahDenda = 0;

            }else if(Hari > 5 && Hari <=10 ){
                Hari -= 5;
                int Denda1 = 10000;
                JumlahDenda = Hari * Denda1 ;

            }else if(Hari > 10 && Hari <=30){
                Hari -= 10;
                int Denda2 = 20000;
                JumlahDenda = DendaLimaHari + (Hari * Denda2);

            }else if(Hari > 30){
                Console.WriteLine("Keanggotaan anda dibatalkan.");
                Hari -= 30;
                int Denda3 = 30000;
                JumlahDenda = (DendaLimaHari + DendaSetelahLimaHari) + (Hari * Denda3);
                
            }else{

            }
            Console.WriteLine("Total denda : Rp" + JumlahDenda);
        }
    }
}
