﻿using System;

namespace UTS-NameTag
{
    class Program
    {
        static void Main(string[] args)
        {
            string Nama;
            string NIM;
            string Konsentrasi;

            Console.WriteLine("Nama : ");
            Nama = Console.ReadLine();
            Console.WriteLine("NIM : ");
            NIM = Console.ReadLine();
            Console.WriteLine("Konsentrasi : ");
            Konsentrasi = Console.ReadLine();

            Console.WriteLine("|**************************************|");
            Console.WriteLine("{0,-20} {1,19}" , "|Nama       : " , Nama + "|");
            Console.WriteLine("{0,-20} {1,19}"  ,"|" , NIM + "|");
            Console.WriteLine("|--------------------------------------|");
            Console.WriteLine("{0,-5} {1,34}"  , "|" , Konsentrasi + "|");
            Console.WriteLine("|**************************************|");
            Console.WriteLine();
        }
    }
}

