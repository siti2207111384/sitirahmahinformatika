﻿using System;

namespace BattleTank
{
    class Program
    {
        static void Main(string[] args)
        {
            //Inisialisasi variabel yang dibutuhkan
            int PanjangArea = 5;
            char Rumput = '.';
            char Tank = 't';
            char Hit = 'X';
            char Miss = 'O';
            int JumlahTank = 3;

            char[,] playArea = BuatRuang(PanjangArea,Rumput,Tank,JumlahTank);

            printArea(playArea,Rumput,Tank);

            int JumlahTankTersembunyi = JumlahTank;

            //GamePlay
            while(JumlahTankTersembunyi>0){
                int[] tebakKoordinat = getKoordinatTebakan(PanjangArea);
                char updateTampilanArea = verifikasiTebakan(tebakKoordinat, playArea, Tank, Rumput, Hit, Miss);
                if(updateTampilanArea == Hit){
                    JumlahTankTersembunyi--;
                }
                playArea = updateRuangan(playArea, tebakKoordinat, updateTampilanArea);
                printArea(playArea, Rumput, Tank);

            }

            Console.WriteLine("You, Game Over!");
            Console.Read();
            Console.Clear();

        }

        //membuat area permainan
        private static char[,] BuatRuang(int PanjangArea, char Rumput, char Tank, int JumlahTank){
            char[,] Ruangan = new char[PanjangArea,PanjangArea];
            for (int baris = 0; baris < PanjangArea; baris++)
            {
                for(int kolom = 0; kolom < PanjangArea; kolom++)
                {
                    Ruangan[baris,kolom] = Rumput;
                }
            }

            return LetakkanTank(Ruangan,JumlahTank,Rumput,Tank);
        }

        //meletakkan tank dalam area
        static char[,] LetakkanTank(char[,] Ruangan, int JumlahTank, char Rumput, char Tank){
            int LetakTank = 0;
            int PanjangArea = 5;

            while(LetakTank<JumlahTank){
                int[] LokasiTank = tentukanKoordinatTank(PanjangArea);
                char Posisi = Ruangan[LokasiTank[0],LokasiTank[1]];

                if(Posisi==Rumput){
                    Ruangan[LokasiTank[0],LokasiTank[1]] = Tank;
                    LetakTank++;
                }
            }

            return Ruangan;
        }

        //menentukan posisi koordinat tank (x,y)
        private static int[] tentukanKoordinatTank(int PanjangArea){
            Random rng = new Random();
            int[] koordinat = new int[2];

            for(int i=0; i < koordinat.Length; i++)
            {
                koordinat[i] = rng.Next(PanjangArea);//x = random(0,4) ; y = random(0,4)
            }

            return koordinat;
        }

        //menampilkan area permainan ke console
        private static void printArea(char[,] playArea, char Rumput, char Tank){
            Console.Write(" ");
            for(int i = 0; i < 5; i++)
            {
                Console.Write(i + 1 + " ");// 1 2 3 4 5 
            }
            Console.WriteLine();

            for(int baris = 0; baris < 5; baris++)
            {
                Console.Write(baris + 1 +" ");
                for(int kolom = 0;kolom<5;kolom++){
                    char Posisi = playArea[baris,kolom];
                    if(Posisi == Tank){
                        Console.Write(Rumput + " ");
                    }else{
                        Console.Write(Posisi + " ");
                    }
            }
            Console.WriteLine("");
        }
    }

    //Tebakan Koordinat Pemain
    static int[] getKoordinatTebakan(int PanjangArea){
        int baris;
        int kolom;

        do{
            Console.Write("Pilih Baris : ");
            baris = Convert.ToInt32(Console.ReadLine());
        }while(baris<0 || baris>PanjangArea + 1);

        do{
           Console.Write("Pilih Kolom : ");
           kolom = Convert.ToInt32(Console.ReadLine()); 
        }while(kolom<0 || kolom>PanjangArea + 1);

        return new[]{baris-1, kolom-1};

        }

        //Verifikasi Tebakan pemain
        private static char verifikasiTebakan(int [] tebakKoordinat, char[,] playArea, char Tank,
        char Rumput, char Hit, char Miss){

        string pesan;
        int baris = tebakKoordinat[0];
        int kolom = tebakKoordinat[1];
        char target = playArea[baris,kolom];

        if(target == Tank){
            pesan = "hit!";
            target = Hit;
        }else if(target == Rumput){
            pesan = "Tembakan meleset!";
            target = Miss;
        }else{
            pesan = "Area ini aman";
        }

        Console.WriteLine(pesan);
        Console.WriteLine(" ");
        return target;
        
        }
        
        private static char[,] updateRuangan(char[,] Ruang, int[] tebakKoordinat, char updateTampilanArea){
            int baris = tebakKoordinat[0];
            int kolom = tebakKoordinat[1];

            Ruang[baris, kolom] = updateTampilanArea;
            return Ruang;
        }
    }
}
